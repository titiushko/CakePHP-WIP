<?php
App::uses('UploadBehavior', 'Upload.Model/Behavior');
class FileImportBehavior extends UploadBehavior {

}
